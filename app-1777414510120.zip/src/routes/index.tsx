import { createFileRoute } from '@tanstack/react-router'
import { Link } from '@tanstack/react-router'
import * as React from 'react'
import { useMutation } from 'convex/react'
import { api } from '../../convex/_generated/api'

export const Route = createFileRoute('/')({
  head: () => ({
    meta: [
      {
        title: 'Dream House Construction | Building Your Vision',
      },
      {
        name: 'description',
        content: 'Luxurious, custom-built homes designed for modern living. Craftsmanship and trust in every brick.',
      },
    ],
  }),
  component: Home,
})

function Home() {
  const sendInquiry = useMutation(api.inquiries.sendInquiry)
  const [formStatus, setFormStatus] = React.useState<'idle' | 'sending' | 'sent'>('idle')

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setFormStatus('sending')
    const formData = new FormData(e.currentTarget)
    await sendInquiry({
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      phone: formData.get('phone') as string,
      message: formData.get('message') as string,
    })
    setFormStatus('sent')
    e.currentTarget.reset()
    setTimeout(() => setFormStatus('idle'), 5000)
  }
  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#333333] font-sans selection:bg-[#C5A059] selection:text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#333333] flex items-center justify-center">
              <span className="text-[#C5A059] font-serif text-xl italic font-bold">D</span>
            </div>
            <span className="text-xl font-serif tracking-tight font-bold uppercase">Dream House</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8 text-sm uppercase tracking-widest font-medium">
            <Link to="/" className="text-[#C5A059]">Home</Link>
            <a href="#about" className="hover:text-[#C5A059] transition-colors">About</a>
            <a href="#services" className="hover:text-[#C5A059] transition-colors">Services</a>
            <a href="#projects" className="hover:text-[#C5A059] transition-colors">Projects</a>
            <a href="#contact" className="hover:text-[#C5A059] transition-colors">Contact</a>
          </div>

          <button className="bg-[#333333] text-white px-6 py-2.5 text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors duration-300">
            Get a Quote
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop" 
            alt="Luxury modern home" 
            className="w-full h-full object-cover scale-105 animate-slow-zoom"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
          <p className="text-[#C5A059] uppercase tracking-[0.3em] mb-4 text-sm font-semibold animate-fade-in-up">Luxury Custom Builders</p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif font-light mb-8 leading-tight animate-fade-in-up [animation-delay:200ms]">
            Building Your Dream, <br />
            <span className="italic">Brick by Brick</span>
          </h1>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 animate-fade-in-up [animation-delay:400ms]">
            <button className="w-full sm:w-auto bg-[#C5A059] text-white px-10 py-4 text-sm uppercase tracking-widest hover:bg-white hover:text-[#333333] transition-all duration-300">
              Get a Quote
            </button>
            <button className="w-full sm:w-auto border border-white/50 text-white px-10 py-4 text-sm uppercase tracking-widest hover:bg-white hover:text-[#333333] transition-all duration-300 backdrop-blur-sm">
              View Projects
            </button>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-px h-12 bg-gradient-to-b from-white to-transparent"></div>
        </div>
      </section>

      {/* Intro Section */}
      <section id="about" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1600607687940-4e2a09695d51?q=80&w=2070&auto=format&fit=crop" 
              alt="Architectural detail" 
              className="w-full aspect-[4/5] object-cover shadow-2xl"
            />
            <div className="absolute -bottom-8 -right-8 bg-white p-12 hidden md:block shadow-xl">
              <div className="text-4xl font-serif italic text-[#C5A059]">25+</div>
              <div className="text-xs uppercase tracking-widest mt-2">Years of Excellence</div>
            </div>
          </div>
          <div>
            <span className="text-[#C5A059] uppercase tracking-widest text-sm font-semibold mb-4 block">Who We Are</span>
            <h2 className="text-4xl md:text-5xl font-serif mb-8 text-[#333333]">Turning Your Vision into an Architectural Masterpiece</h2>
            <p className="text-gray-600 text-lg mb-8 leading-relaxed">
              At Dream House Construction, we believe a home is more than just a structure. It's a reflection of your legacy, your tastes, and your future. Our master craftsmen and visionary architects work in harmony to deliver unparalleled luxury.
            </p>
            <div className="space-y-4 mb-10">
              {['Bespoke Design Philosophy', 'Premium Sustainable Materials', 'Meticulous Attention to Detail'].map((item) => (
                <div key={item} className="flex items-center gap-4">
                  <div className="w-5 h-px bg-[#C5A059]"></div>
                  <span className="text-sm uppercase tracking-wider font-medium">{item}</span>
                </div>
              ))}
            </div>
            <button className="border-b border-[#C5A059] pb-2 text-[#333333] uppercase tracking-widest text-sm font-bold hover:text-[#C5A059] transition-colors">
              Our Story
            </button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <span className="text-[#C5A059] uppercase tracking-widest text-sm font-semibold mb-4 block">Our Expertise</span>
            <h2 className="text-4xl md:text-5xl font-serif text-[#333333]">Comprehensive Building Solutions</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
            {[
              {
                title: 'Custom Home Building',
                desc: 'Tailored architectural marvels designed around your lifestyle and preferences.',
                icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'
              },
              {
                title: 'Architectural Design',
                desc: 'Visionary blueprints that blend aesthetic beauty with functional excellence.',
                icon: 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 4L9 7'
              },
              {
                title: 'Renovations & Remodeling',
                desc: 'Transforming existing spaces into modern masterpieces with heritage in mind.',
                icon: 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z'
              },
              {
                title: 'Interior Finishing',
                desc: 'Exquisite details and high-end materials that define true luxury living.',
                icon: 'M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z'
              }
            ].map((service, i) => (
              <div key={i} className="group p-8 border border-gray-100 hover:border-[#C5A059] transition-all duration-500">
                <div className="w-12 h-12 mb-8 text-[#C5A059]">
                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d={service.icon} />
                  </svg>
                </div>
                <h3 className="text-xl font-serif mb-4 text-[#333333]">{service.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-6">{service.desc}</p>
                <button className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#C5A059] group-hover:translate-x-2 transition-transform">
                  Learn More →
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects Preview */}
      <section id="projects" className="bg-[#333333] py-24 px-6 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
            <div>
              <span className="text-[#C5A059] uppercase tracking-widest text-sm font-semibold mb-4 block">Portfolio</span>
              <h2 className="text-4xl md:text-5xl font-serif">Featured Residences</h2>
            </div>
            <button className="bg-transparent border border-white/20 px-8 py-3 text-xs uppercase tracking-widest hover:bg-white hover:text-[#333333] transition-all">
              View All Projects
            </button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'The Glass Pavilion', category: 'Modern', img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2070&auto=format&fit=crop' },
              { title: 'Golden Sands Estate', category: 'Luxury', img: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=2071&auto=format&fit=crop' },
              { title: 'Emerald Valley Villa', category: 'Eco-Friendly', img: 'https://images.unsplash.com/photo-1600566753190-17f0bb2a6c3e?q=80&w=2070&auto=format&fit=crop' },
            ].map((project, i) => (
              <div key={i} className="group cursor-pointer">
                <div className="relative overflow-hidden aspect-[3/4]">
                  <img 
                    src={project.img} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="absolute bottom-0 left-0 p-8 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    <p className="text-[#C5A059] text-xs uppercase tracking-widest mb-2">{project.category}</p>
                    <h3 className="text-2xl font-serif">{project.title}</h3>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 px-6 bg-[#F5F5DC]/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-[#C5A059] uppercase tracking-widest text-sm font-semibold mb-4 block">Kind Words</span>
            <h2 className="text-4xl md:text-5xl font-serif text-[#333333]">Client Experiences</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {[
              {
                name: 'Alexander & Sarah Thorne',
                text: 'Dream House Construction didn’t just build our home; they built our sanctuary. Their attention to detail and commitment to excellence is truly unmatched in the industry.',
                role: 'Custom Home Owners',
                img: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=400&auto=format&fit=crop'
              },
              {
                name: 'Julian Montgomery',
                text: 'The architectural design team is visionary. They took our abstract ideas and turned them into a breathtaking reality that exceeded every expectation.',
                role: 'Villa Owner',
                img: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=400&auto=format&fit=crop'
              }
            ].map((t, i) => (
              <div key={i} className="bg-white p-12 shadow-sm border-t-4 border-[#C5A059]">
                <div className="flex items-center gap-4 mb-8">
                  <div className="flex text-[#C5A059]">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-4 h-4 fill-current" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-xl italic text-gray-600 mb-8 leading-relaxed">"{t.text}"</p>
                <div className="flex items-center gap-4">
                  <img src={t.img} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h4 className="font-bold text-[#333333]">{t.name}</h4>
                    <p className="text-xs uppercase tracking-widest text-[#C5A059]">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-20">
          <div>
            <span className="text-[#C5A059] uppercase tracking-widest text-sm font-semibold mb-4 block">Inquiries</span>
            <h2 className="text-4xl md:text-5xl font-serif mb-8 text-[#333333]">Let's Discuss Your Vision</h2>
            <p className="text-gray-600 text-lg mb-12 leading-relaxed">
              Ready to begin your journey toward the perfect home? Our consultants are here to guide you through every step of the process.
            </p>
            
            <div className="space-y-8">
              {[
                { label: 'Address', value: '123 Luxury Lane, Beverly Hills, CA 90210', icon: 'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z M15 11a3 3 0 11-6 0 3 3 0 016 0z' },
                { label: 'Phone', value: '+1 (800) DREAM-HS', icon: 'M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z' },
                { label: 'Email', value: 'concierge@dreamhouse.build', icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 012-2V7a2 2 0 01-2-2H5a2 2 0 01-2 2v10a2 2 0 012 2z' }
              ].map((item, i) => (
                <div key={i} className="flex gap-6">
                  <div className="w-6 h-6 text-[#C5A059] shrink-0">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d={item.icon} />
                    </svg>
                  </div>
                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-bold text-[#333333] mb-1">{item.label}</h4>
                    <p className="text-gray-600">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-10 shadow-2xl">
            {formStatus === 'sent' ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center">
                  <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-2xl font-serif">Message Received</h3>
                <p className="text-gray-500">A luxury consultant will reach out to you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest font-bold">Full Name</label>
                    <input name="name" required className="w-full border-b border-gray-200 py-3 focus:border-[#C5A059] transition-colors outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest font-bold">Email Address</label>
                    <input name="email" type="email" required className="w-full border-b border-gray-200 py-3 focus:border-[#C5A059] transition-colors outline-none" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Phone Number</label>
                  <input name="phone" required className="w-full border-b border-gray-200 py-3 focus:border-[#C5A059] transition-colors outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Project Vision</label>
                  <textarea name="message" rows={4} required className="w-full border border-gray-100 p-4 focus:border-[#C5A059] transition-colors outline-none resize-none" placeholder="Tell us about your dream home..."></textarea>
                </div>
                <button 
                  disabled={formStatus === 'sending'}
                  className="w-full bg-[#333333] text-white py-4 text-xs uppercase tracking-widest hover:bg-[#C5A059] transition-colors disabled:opacity-50"
                >
                  {formStatus === 'sending' ? 'Sending...' : 'Request Consultation'}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Footer (Mini) */}
      <footer className="py-12 px-6 border-t border-gray-100">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-[#333333] flex items-center justify-center">
              <span className="text-[#C5A059] font-serif text-sm italic font-bold">D</span>
            </div>
            <span className="text-sm font-serif tracking-tight font-bold uppercase">Dream House</span>
          </div>
          <p className="text-gray-400 text-xs uppercase tracking-widest">
            © 2024 Dream House Construction. All Rights Reserved.
          </p>
          <div className="flex gap-6 text-xs uppercase tracking-widest font-medium">
            <a href="#" className="hover:text-[#C5A059]">Instagram</a>
            <a href="#" className="hover:text-[#C5A059]">LinkedIn</a>
            <a href="#" className="hover:text-[#C5A059]">Facebook</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
